const { coinsList } = require('./coinsList');

module.exports = {
    coin: coinsList['IPSUM'],
    refreshTime: 180,
    masternodesOnPage: 50,
    mainColor: '#007bff'
}

// module.exports = {
//     coin: coinsList['CRAVE'],
//     refreshTime: 180,
//     masternodesOnPage: 50,
//     mainColor: '#40B8CC '
// }

