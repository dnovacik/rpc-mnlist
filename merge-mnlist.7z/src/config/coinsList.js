module.exports = {
    coinsList: {
        'CRAVE': {
            'ticker': 'craveng',
            'name': 'Crave-NG',
            'iconurl': 'https://masternodes.online/coin_image/CRAVE.png',
            'rpchost': '144.202.54.242',
            'rpcport': '6666',
            'rpcuser': 'craverpc',
            'rpcpass': '6G8TRVUJeGfRzAF3eT6orrsT9c6nnDPfj8L'
        },
        'IPSUM': {
            'ticker': 'IPS',
            'name': 'IPSUM',
            'iconurl': 'https://masternodes.online/coin_image/IPS.png',
            'rpchost': '95.179.162.143',
            'rpcport': '22332',
            'rpcuser': 'ipsum-api-node-vultr-1',
            'rpcpass': 'paraVidaFortunente'
        }
    }
}